namespace TestAPIProject.Request
{
    public class LoactionRequest
    {
        public string title { get; set; }
        public string city { get; set; }

        public string state { get; set; }   

        public string country { get; set; }

        public string zipcode { get; set; }
    }
}

