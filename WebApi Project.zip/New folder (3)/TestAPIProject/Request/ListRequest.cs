using System;

namespace TestAPIProject.Request
{
    public class ListRequest
    {
        public string searchString { get; set; }
        public int pageNo { get; set; }

        public int pageSize {get; set; }

        public int departmentId { get; set; }

        public int locationId { get; set; }

    }
}

