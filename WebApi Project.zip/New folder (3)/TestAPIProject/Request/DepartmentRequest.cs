namespace TestAPIProject.Request
{
    public class DepartmentRequest
    {
       // public int DepartmentId { get; set; }

        public string Departmenttitle { get; set; }
    }
}

