﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TestAPIProject.Models
{
    public partial class Department
    {
        public Department()
        {
            JobOpenings = new HashSet<JobOpening>();
        }

        public int Departmentid { get; set; }
        public string Departmenttitle { get; set; }

        public virtual ICollection<JobOpening> JobOpenings { get; set; }
    }
}
