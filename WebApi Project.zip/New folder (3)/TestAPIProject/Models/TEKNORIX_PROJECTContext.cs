﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace TestAPIProject.Models
{
    public partial class TEKNORIX_PROJECTContext : DbContext
    {
        public TEKNORIX_PROJECTContext()
        {
        }

        public TEKNORIX_PROJECTContext(DbContextOptions<TEKNORIX_PROJECTContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Department> Departments { get; set; }
        public virtual DbSet<JobOpening> JobOpenings { get; set; }
        public virtual DbSet<Location> Locations { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {

            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Department>(entity =>
            {
                entity.ToTable("DEPARTMENT");

                entity.Property(e => e.Departmentid).HasColumnName("DEPARTMENTID");

                entity.Property(e => e.Departmenttitle)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("DEPARTMENTTITLE");
            });

            modelBuilder.Entity<JobOpening>(entity =>
            {
                entity.ToTable("JOB_OPENING");

                entity.Property(e => e.Jobopeningid).HasColumnName("JOBOPENINGID");

                entity.Property(e => e.Departmentid).HasColumnName("DEPARTMENTID");

                entity.Property(e => e.Jobclosingdate)
                    .HasColumnType("date")
                    .HasColumnName("JOBCLOSINGDATE");

                entity.Property(e => e.Jobcode)
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasColumnName("JOBCODE");

                entity.Property(e => e.Jobdescription)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("JOBDESCRIPTION");

                entity.Property(e => e.Jobposteddate)
                    .HasColumnType("date")
                    .HasColumnName("JOBPOSTEDDATE");

                entity.Property(e => e.Jobtitle)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("JOBTITLE");

                entity.Property(e => e.Locationid).HasColumnName("LOCATIONID");

                entity.HasOne(d => d.Department)
                    .WithMany(p => p.JobOpenings)
                    .HasForeignKey(d => d.Departmentid)
                    .HasConstraintName("FK__JOB_OPENI__DEPAR__4F7CD00D");

                entity.HasOne(d => d.Location)
                    .WithMany(p => p.JobOpenings)
                    .HasForeignKey(d => d.Locationid)
                    .HasConstraintName("FK__JOB_OPENI__LOCAT__5070F446");
            });

            modelBuilder.Entity<Location>(entity =>
            {
                entity.ToTable("LOCATION");

                entity.Property(e => e.Locationid).HasColumnName("LOCATIONID");

                entity.Property(e => e.City)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("CITY");

                entity.Property(e => e.Country)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("COUNTRY");

                entity.Property(e => e.Locationtitle)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("LOCATIONTITLE");

                entity.Property(e => e.State)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("STATE");

                entity.Property(e => e.Zipcode)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("ZIPCODE");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
