﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TestAPIProject.Models
{
    public partial class JobOpening
    {
        public int Jobopeningid { get; set; }
        public string Jobcode { get; set; }
        public string Jobtitle { get; set; }
        public string Jobdescription { get; set; }
        public DateTime? Jobposteddate { get; set; }
        public DateTime? Jobclosingdate { get; set; }
        public int? Departmentid { get; set; }
        public int? Locationid { get; set; }

        public virtual Department Department { get; set; }
        public virtual Location Location { get; set; }
    }
}
