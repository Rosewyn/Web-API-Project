﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TestAPIProject.Models
{
    public partial class Location
    {
        public Location()
        {
            JobOpenings = new HashSet<JobOpening>();
        }

        public int Locationid { get; set; }
        public string Locationtitle { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public string Zipcode { get; set; }

        public virtual ICollection<JobOpening> JobOpenings { get; set; }
    }
}
