using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Query.SqlExpressions;
using Microsoft.Extensions.Logging;
using TestAPIProject.Models;
using TestAPIProject.Request;


namespace TestAPIProject.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class JobController : ControllerBase
    {
        private readonly TEKNORIX_PROJECTContext _DBContext;

        public JobController(TEKNORIX_PROJECTContext _DBContext)
        {
            this._DBContext=_DBContext;
        }


        [HttpGet("Get/{id}")]
        public IActionResult Get(int id)
        {
            var job =(from JO in this._DBContext.JobOpenings
                      join L in this._DBContext.Locations on JO.Locationid equals L.Locationid
                      join D in this._DBContext.Departments on JO.Departmentid equals D.Departmentid
                      where JO.Jobopeningid ==id
                      select new {
                        id=JO.Jobopeningid,
                        code=JO.Jobcode,
                        title=JO.Jobtitle,
                        description=JO.Jobdescription,
                        location = new {
                            id= L.Locationid,
                            title =L.Locationtitle,
                            city = L.City,
                            state=L.State,
                            country = L.Country,
                            zip = L.Zipcode
                        },
                        department = new {
                            id = D.Departmentid,
                            title= D.Departmenttitle
                        },
                        postedDate=JO.Jobposteddate,
                        closingDate = JO.Jobclosingdate

                      } ).ToList();


            return Ok(job);
        }


        [HttpPost("create")]
        public IActionResult Insert([FromBody]JobOpeningRequest request)
        {
            JobOpening obj = new JobOpening();
            obj.Jobtitle= request.title;
            obj.Jobdescription = request.description;
            obj.Locationid = request.locationId;
            obj.Departmentid = request.departmentId;
            obj.Jobclosingdate = request.closingDate;;

            this._DBContext.JobOpenings.Add(obj);
            this._DBContext.SaveChanges();
            return Ok();
        }
            
        [HttpPut("Update/{id}")]
        public IActionResult UpdateJob(int id, [FromBody]JobOpeningRequest request)
        {

            var obj =  this._DBContext.JobOpenings.FirstOrDefault(a=>a.Jobopeningid==id);
                obj.Jobtitle=request.title!=null?request.title:obj.Jobtitle;
                obj.Jobdescription = request.description!=null?request.description:obj.Jobdescription;
                obj.Locationid = request.locationId!=0?request.locationId:obj.Locationid;
                obj.Departmentid = request.departmentId!=0?request.departmentId:obj.Departmentid;
                obj.Jobclosingdate =request.closingDate;

            this._DBContext.SaveChanges();
            return Ok();
            
        }

        [HttpPost("List")]
        public IActionResult List([FromBody]ListRequest request)
        {
            var obj= (from JO in this._DBContext.JobOpenings
                      join L in this._DBContext.Locations on JO.Locationid equals L.Locationid
                      join D in this._DBContext.Departments on JO.Departmentid equals D.Departmentid
                      where L.Locationid== request.locationId || D.Departmentid == request.departmentId
                      select new {
                         id=JO.Jobopeningid,
                        code=JO.Jobcode,
                        title=JO.Jobtitle,
                        description=JO.Jobdescription,
                        location =L.Locationtitle,
                        department= D.Departmenttitle,
                        postedDate=JO.Jobposteddate,
                        closingDate = JO.Jobclosingdate
                      }).ToList();
            return Ok(obj);
        }
            
    }
}
    

