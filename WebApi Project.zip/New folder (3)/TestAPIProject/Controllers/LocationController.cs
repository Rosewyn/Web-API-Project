using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using TestAPIProject.Models;
using TestAPIProject.Request;

namespace TestAPIProject.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class LocationController : ControllerBase
    {
        private readonly TEKNORIX_PROJECTContext _DBContext;

        public LocationController(TEKNORIX_PROJECTContext _DBContext)
        {
            this._DBContext=_DBContext;
        }

        [HttpGet("GetAll")]
        public IActionResult GetAll()
        {
            var locations =( from L in this._DBContext.Locations
                            select new {
                                 id= L.Locationid,
                            title =L.Locationtitle,
                            city = L.City,
                            state=L.State,
                            country = L.Country,
                            zip = L.Zipcode
                            }).ToList();
            return Ok(locations);
        }

        [HttpPost("create")]
        public IActionResult Insert([FromBody]LoactionRequest request)
        {
            Location obj = new Location();
            obj.Locationtitle= request.title;
           obj.State = request.state;
           obj.City = request.city;
           obj.Country = request.country;
           obj.Zipcode = request.zipcode;

            this._DBContext.Locations.Add(obj);
            this._DBContext.SaveChanges();
            return Ok();
        }
            
        [HttpPut("Update/{id}")]
        public IActionResult UpdateJob(int id, [FromBody]LoactionRequest request)
        {
            var obj =  this._DBContext.Locations.FirstOrDefault(a=>a.Locationid==id);            
             obj.Locationtitle = request.title;
             obj.City = request.city;
             obj.State = request.state;
             obj.Country = request.country;
             obj.Zipcode= request.zipcode;

            this._DBContext.SaveChanges();
            return Ok();
            //}
           // return Ok("False");
        }
            
    }
}
    

