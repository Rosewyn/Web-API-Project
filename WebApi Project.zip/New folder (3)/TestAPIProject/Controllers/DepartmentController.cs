using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using TestAPIProject.Models;
using TestAPIProject.Request;

namespace TestAPIProject.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class DepartmentController : ControllerBase
    {
        private readonly TEKNORIX_PROJECTContext _DBContext;

        public DepartmentController(TEKNORIX_PROJECTContext _DBContext)
        {
            this._DBContext=_DBContext;
        }

        [HttpGet("GetAll")]
        public IActionResult GetAll()
        {
            var Departments =( from D in this._DBContext.Departments
                                select new {
                                  id = D.Departmentid,
                                  title= D.Departmenttitle  
                                }).ToList();
            return Ok(Departments);
        }

        [HttpPost("create")]
        public IActionResult Insert([FromBody]DepartmentRequest request)
        {
            Department obj = new Department();
           obj.Departmenttitle = request.Departmenttitle;

            this._DBContext.Departments.Add(obj);
            this._DBContext.SaveChanges();
            return Ok();
        }
            
        [HttpPut("Update/{id}")]
        public IActionResult UpdateJob(int id, [FromBody]DepartmentRequest request)
        {
            var obj =  this._DBContext.Departments.FirstOrDefault(a=>a.Departmentid==id);            
             obj.Departmenttitle = request.Departmenttitle;

            this._DBContext.SaveChanges();
            return Ok();
        }
            
    }
}
    

